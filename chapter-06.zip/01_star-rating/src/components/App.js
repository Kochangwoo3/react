import React from "react";
import StarRating from "./StarRating";

function App() {
  return (
    <StarRating />
  );
}

export default App;
