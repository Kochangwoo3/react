import React from 'react';

const BoardModify = () => {
  return <div></div>;
};

export default BoardModify;
