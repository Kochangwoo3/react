import React from 'react';

const BoardList = () => {
  return <div></div>;
};

export default BoardList;
