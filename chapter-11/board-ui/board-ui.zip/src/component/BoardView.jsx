import React from 'react';

const BoardView = () => {
  return <div></div>;
};

export default BoardView;
