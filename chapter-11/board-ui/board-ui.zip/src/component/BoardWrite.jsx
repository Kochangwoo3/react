import React from 'react';

const BoardWrite = () => {
  return <div></div>;
};

export default BoardWrite;
