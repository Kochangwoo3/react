import './App.css';
import BoardMain from './component/BoardMain';
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  return (
    <div className="App">
      <BoardMain />
    </div>
  );
}

export default App;
