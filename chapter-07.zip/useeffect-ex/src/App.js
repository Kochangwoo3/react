import React from 'react';
import Useeffect01 from './components/Useeffect01';
import Useeffect02 from './components/Useeffect02';
import Useeffect03 from './components/Useeffect03';
import Useeffect04 from './components/Useeffect04';
import Useeffect05 from './components/Useeffect05';
import Useeffect06 from './components/Useeffect06';
import Useeffect07 from './components/Useeffect07';
import Useeffect08 from './components/Useeffect08';
import Useeffect09 from './components/Useeffect09';
import Useeffect10 from './components/Useeffect10';

function App() {
  return (
    <>
      <Useeffect10 />
    </>
  );
}

export default App;
