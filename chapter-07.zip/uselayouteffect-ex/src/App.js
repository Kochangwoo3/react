import Uselayouteffect03 from './components/Uselayouteffect03';

function App() {
  return <Uselayouteffect03 />;
}

export default App;
