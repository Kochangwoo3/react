import React from 'react';
import Usereducer01 from './components/Usereducer01';
import Usereducer02 from './components/Usereducer02';
import Usereducer03 from './components/Usereducer03';
import Usereducer04 from './components/Usereducer04';
import Usereducercomplex0 from './components/Usereducercomplex0';
import Usereducercomplex1 from './components/Usereducercomplex1';
import Usereducercomplex2 from './components/Usereducercomplex2';

function App() {
  return <Usereducercomplex2 />;
}

export default App;
